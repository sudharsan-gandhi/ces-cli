export class BadRequest extends Error {}

export class Conflict extends Error {}

export class NotFound extends Error {}

export class Unauthorize extends Error {}
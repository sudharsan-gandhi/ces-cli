const Types = {

    Controller: Symbol('Controller'),

    UserRepository: Symbol('UserRepository'),

    UserService: Symbol('UserService')

};

export default Types;